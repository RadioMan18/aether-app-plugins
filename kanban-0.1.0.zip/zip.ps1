$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath 'D:\src\aether-app-suite\plugins\kanban\kanban-0.1.0.zip') {
  Remove-Item -LiteralPath 'D:\src\aether-app-suite\plugins\kanban\kanban-0.1.0.zip' -Force
}
Compress-Archive -Path 'D:\src\aether-app-suite\plugins\kanban\.zip-temp-1789668927076\*' -DestinationPath 'D:\src\aether-app-suite\plugins\kanban\kanban-0.1.0.zip' -Force