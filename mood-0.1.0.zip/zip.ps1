$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath 'D:\src\aether-app-suite\plugins\mood\mood-0.1.0.zip') {
  Remove-Item -LiteralPath 'D:\src\aether-app-suite\plugins\mood\mood-0.1.0.zip' -Force
}
Compress-Archive -Path 'D:\src\aether-app-suite\plugins\mood\.zip-temp-1789668918530\*' -DestinationPath 'D:\src\aether-app-suite\plugins\mood\mood-0.1.0.zip' -Force