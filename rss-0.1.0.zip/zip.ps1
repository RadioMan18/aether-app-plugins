$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath 'D:\src\aether-app-suite\plugins\rss\rss-0.1.0.zip') {
  Remove-Item -LiteralPath 'D:\src\aether-app-suite\plugins\rss\rss-0.1.0.zip' -Force
}
Compress-Archive -Path 'D:\src\aether-app-suite\plugins\rss\.zip-temp-1789668912844\*' -DestinationPath 'D:\src\aether-app-suite\plugins\rss\rss-0.1.0.zip' -Force