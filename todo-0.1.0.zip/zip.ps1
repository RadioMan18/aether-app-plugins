$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath 'D:\src\aether-app-suite\plugins\todo\todo-0.1.0.zip') {
  Remove-Item -LiteralPath 'D:\src\aether-app-suite\plugins\todo\todo-0.1.0.zip' -Force
}
Compress-Archive -Path 'D:\src\aether-app-suite\plugins\todo\.zip-temp-1789668907239\*' -DestinationPath 'D:\src\aether-app-suite\plugins\todo\todo-0.1.0.zip' -Force